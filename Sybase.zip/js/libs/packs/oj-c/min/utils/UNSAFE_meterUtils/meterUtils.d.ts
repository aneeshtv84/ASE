import { Threshold } from '@oracle/oraclejet-preact/utils/UNSAFE_meterTypes';
export declare const getThresholdColorByIndex: (threshold: Threshold, index: number) => string;
