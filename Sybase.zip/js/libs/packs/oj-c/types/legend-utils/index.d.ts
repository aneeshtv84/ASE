export { getPreferredSize } from './legendUtils';
