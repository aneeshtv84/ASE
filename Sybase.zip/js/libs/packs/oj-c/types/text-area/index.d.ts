export { TextArea } from './text-area';
export { CTextAreaElement } from './text-area';